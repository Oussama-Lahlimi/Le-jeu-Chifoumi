# Challenge project - Build a minigame console app with GitHub Copilot

Starter and Final code for the Challenge project: "Challenge project - Build a minigame console app with GitHub Copilot". To check the solution, change the branch to **Solution**.